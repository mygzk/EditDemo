package com.zayh.epolice.prermission;

import android.Manifest;
import android.support.annotation.NonNull;

/**
 * Created by：guozhk
 * date: 16-10-27 14:54
 */
public class PermissionConstant {

    //权限检测 请求码
    public static final int REQUEST_CODE = 0; // 请求码
    public static final String[] PERMISSIONS = new String[]{
            //访问网络，网络定位需要上网
            Manifest.permission.INTERNET,
            // 获取运营商信息，用于支持提供运营商信息相关的接口
            Manifest.permission.ACCESS_NETWORK_STATE,
            //这个权限用于获取wifi的获取权限，wifi信息会用来进行网络定位
            Manifest.permission.CHANGE_WIFI_STATE,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.SEND_SMS,
            Manifest.permission.CAMERA,
            //允许应用程序更改主屏幕中的设置和快捷方式
           // Manifest.permission.WRITE_SETTINGS,
            Manifest.permission.ACCESS_WIFI_STATE,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.ACCESS_FINE_LOCATION,


            //写入扩展存储，向扩展卡写入数据，用于写入离线定位数据
            Manifest.permission.BROADCAST_STICKY,
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.READ_PHONE_STATE
           // Manifest.permission.SYSTEM_ALERT_WINDOW,
    };

    /**
     * 检测包含谋个权限
     *
     * @param permissions 权限集合
     * @param permiss     检测权限
     * @return boolean
     */
    public static boolean isContansPermiss(@NonNull String[] permissions, String permiss) {
        for (String p : permissions) {
            if (p.equals(permiss)) {
                return true;
            }
        }
        return false;
    }
}
